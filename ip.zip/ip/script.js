
const IP_API = 'https://api.ipify.org/?format=json';
const GEO_API_BASE = 'https://ipinfo.io/';

const infoDiv = document.getElementById('info');
const reloadBtn = document.getElementById('reloadBtn');


async function fetchIpAndGeo() {
    
    infoDiv.innerHTML = '<p class="loading">Загрузка данных...</p>';
    reloadBtn.disabled = true;

    try {
       
        const ipResponse = await fetch(IP_API);
        if (!ipResponse.ok) {
            throw new Error('Ошибка при получении IP адреса');
        }
        const ipData = await ipResponse.json();

        const userIP = ipData.ip;

        
        const geoResponse = await fetch(`${GEO_API_BASE}${userIP}/geo`);
        if (!geoResponse.ok) {
            throw new Error('Ошибка при получении данных геолокации');
        }
        const geoData = await geoResponse.json();

       
        infoDiv.innerHTML = `
            <p><span class="label">IP адрес:</span> ${userIP}</p>
            <p><span class="label">Страна:</span> ${geoData.country || 'неизвестно'}</p>
            <p><span class="label">Регион:</span> ${geoData.region || 'неизвестно'}</p>
            <p><span class="label">Город:</span> ${geoData.city || 'неизвестно'}</p>
        `;
    } catch (error) {
   
        infoDiv.innerHTML = `<p class="error">Ошибка: ${error.message}</p>`;
    } finally {
   
        reloadBtn.disabled = false;
    }
}

reloadBtn.addEventListener('click', () => {
    fetchIpAndGeo();
});

window.addEventListener('load', () => {
    fetchIpAndGeo();
});